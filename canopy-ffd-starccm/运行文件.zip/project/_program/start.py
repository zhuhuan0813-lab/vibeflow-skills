"""Novice entry for the unchanged FFD/STAR pipeline; geometry and CFD remain in core.zip.

Uses per-run folders and an input fingerprint. Menu 3 is the only action that
starts STAR calculation. No installer, global environment change or cleanup.
"""
# 中文阅读顺序：menu（菜单）→ generate（生成几何）→ calculate（启动求解）→ report（汇总）。
# 本文件只负责组织流程，FFD 数学计算和 STAR Java 宏保存在同目录的 core.zip 中。
# 菜单 1 只检查环境，菜单 2 只处理几何；只有菜单 3 会启动实际 CFD 求解。
from pathlib import Path
import argparse
from contextlib import contextmanager
import csv
import datetime as dt
import hashlib
import json
import os
import re
import subprocess
import sys
import uuid
import zipfile

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

# baseline 是原始机身，后面是十个舱盖方案，总共 11 个 CFD 算例。
# 版本约束来自现有 Java 宏；换 STAR 大版本时要重新核对接口。
CASES = ['baseline'] + [f'variant_{i:02d}' for i in range(1, 11)]
EXPECTED_RELEASE = '20.06.007'

class WorkflowError(Exception):
    pass

def read_json(path):
    # utf-8-sig 同时兼容普通 UTF-8 和 Windows 工具写入的 UTF-8 BOM。
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def save_json(path, value):
    # 先写本次独有的临时文件，再替换目标，减少记录写到一半的风险。
    # 这里保存的是设置和状态，不是删除或覆盖原始模型、求解结果。
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp.' + str(os.getpid()) + '.' + uuid.uuid4().hex)
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)

def settings(home):
    # home 由双击入口的位置确定，用户只需保存软件路径，不用填写项目根目录。
    cfg = read_json(home / 'settings.json')
    for key in ['windows_python', 'wsl_python', 'wsl_distro', 'star']:
        if not isinstance(cfg.get(key), str) or not cfg[key].strip():
            raise WorkflowError('软件位置还没有填完整，请先选择菜单 5。')
    return cfg

def capture(args, timeout=90):
    # 用于版本/路径等轻量检查；返回标准输出，失败时带回报错供中文提示展示。
    try:
        p = subprocess.run(list(map(str, args)), capture_output=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as e:
        raise WorkflowError('程序无法启动或检查超时：' + str(args[0]) + '\n' + str(e)) from e
    out = p.stdout.decode('utf-8-sig', errors='replace')
    err = p.stderr.decode('utf-8-sig', errors='replace')
    if p.returncode:
        raise WorkflowError(f'程序返回错误 {p.returncode}：{args[0]}\n' + (err or out)[-1600:])
    return out

def wsl_args(cfg, args):
    # --exec 后直接传程序和独立参数，不把用户路径拼成 bash 命令字符串。
    return ['wsl.exe', '-d', cfg['wsl_distro'], '--exec', *map(str, args)]

def wsl_path(cfg, path):
    # 同一份文件在 Windows 与 WSL 中写法不同，统一交给 wslpath 转换。
    # 取以 / 开头的路径行，避免把 WSL 启动提示误当成目录。
    output = capture(wsl_args(cfg, ['wslpath', '-a', '-u', str(Path(path).resolve())]))
    candidates = [s.strip() for s in output.splitlines() if s.strip().startswith('/')]
    if not candidates:
        raise WorkflowError('无法把项目路径转换为 WSL 路径。请检查菜单 5 的 WSL 发行版。')
    return candidates[-1]

def child(args, logfile, timeout=3600):
    # 每次执行都使用带时间戳的新日志；重试时保留上次日志，便于定位失败阶段。
    # 子程序非零退出立即中止当前流程，避免把部分生成的文件当作完成结果。
    logfile = Path(logfile)
    logfile.parent.mkdir(parents=True, exist_ok=True)
    logfile = logfile.with_name(logfile.stem + '_' + dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f') + logfile.suffix)
    try:
        with logfile.open('xb') as stream:
            p = subprocess.run(list(map(str, args)), stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as e:
        raise WorkflowError('本步骤没有完成。已保留日志：' + str(logfile) + '\n' + str(e)) from e
    if p.returncode:
        raise WorkflowError('本步骤失败，暂不进入下一步。日志：\n' + str(logfile))

def check_windows(cfg):
    # 文件存在不代表解释器可用，因此实际读取 Python 版本和 sys.executable。
    py = Path(cfg['windows_python'])
    if not py.is_file():
        raise WorkflowError('Windows Python 路径无效，请在菜单 5 选择实际 python.exe。')
    value = json.loads(capture([py, '-c', 'import json,sys;print(json.dumps({"version":list(sys.version_info[:3]),"path":sys.executable}))']))
    if value['version'] < [3, 10, 0]:
        raise WorkflowError('需要 Python 3.10 或更新版本。')
    return 'Windows Python ' + '.'.join(map(str, value['version']))

def check_geometry(cfg):
    # 依赖在 WSL 的 Python 中导入；Windows 安装的包不会自动供 WSL 使用。
    output = capture(wsl_args(cfg, [cfg['wsl_python'], '-c', 'import numpy,scipy,pyvista,vtk,matplotlib;print("WSL geometry environment OK")']))
    if 'WSL geometry environment OK' not in output:
        raise WorkflowError('WSL 的 Python 检查没有返回预期结果。')
    return '所需的 5 个 Python 库均可导入'

def check_star(cfg):
    # -version 只验证入口与版本；许可、Java API、建网格是否成功要看实际基线。
    if not Path(cfg['star']).is_file():
        raise WorkflowError('STAR 启动文件不存在，请在菜单 5 选择 starccm+.bat。')
    # .bat needs cmd; list2cmdline follows the original driver's Windows launch convention.
    try:
        p = subprocess.run(subprocess.list2cmdline([cfg['star'], '-version']), shell=True, capture_output=True, timeout=90)
    except (OSError, subprocess.TimeoutExpired) as e:
        raise WorkflowError('STAR 版本检查没有完成：' + str(e)) from e
    output = (p.stdout + p.stderr).decode('utf-8', errors='replace')
    if p.returncode or EXPECTED_RELEASE not in output:
        raise WorkflowError('STAR 版本检查未通过。当前宏需要 2510 / 20.06.007-R8，请核对启动路径和版本。')
    return 'STAR-CCM+ 20.06.007 系列；许可与实际求解将在基线中验证'

def check_environment(home):
    # 各项检查分别记录，出错时让用户知道该修 Python、WSL 还是 STAR 路径。
    cfg = settings(home)
    checks = []
    print('\n正在检查电脑，本步骤不启动 CFD。')
    for name, fn in [('Windows Python', check_windows), ('WSL 与几何依赖', check_geometry), ('STAR 版本', check_star)]:
        try:
            detail = fn(cfg)
            checks.append({'name': name, 'ok': True, 'detail': detail})
            print('  [通过] ' + name + '：' + detail)
        except WorkflowError as e:
            checks.append({'name': name, 'ok': False, 'detail': str(e)})
            print('  [需要处理] ' + name + '：' + str(e))
    save_json(home / '结果' / '电脑检查.json', checks)
    if not all(x['ok'] for x in checks):
        raise WorkflowError('检查没有全部通过。按提示处理；软件位置不对时选择菜单 5。')
    print('\n电脑检查通过。接下来选择 2，生成模型。')

def unpack_core(payload, root):
    # 每次生成都解压到全新批次，保留旧批次；xb 模式不允许覆盖已有文件。
    # CFD 模板放到批次/cfd，其余脚本和输入放到批次/程序，便于区分运行产物。
    root = Path(root).resolve()
    if root.exists():
        raise WorkflowError('本批次目录已存在，程序不会覆盖。')
    root.mkdir(parents=True)
    with zipfile.ZipFile(payload) as z:
        for entry in z.infolist():
            parts = Path(entry.filename).parts
            if not parts or parts[0] != 'project' or '..' in parts:
                raise WorkflowError('运行包目录不正确。')
            rel = Path(*parts[1:])
            if not rel.parts:
                continue
            if rel.parts[0] == 'cfd':
                target = root / rel
            else:
                target = root / '程序' / rel
            target = target.resolve()
            # ZIP 成员只能写入本批次目录，不能通过 ../ 等路径写到其他位置。
            if not target.is_relative_to(root):
                raise WorkflowError('运行包包含越界路径。')
            if entry.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as out:
                    out.write(z.read(entry))

def contract(cfd):
    # 简易入口锁定已确认的工况和完整 10 方案，防止改一个数字却沿用不适配的宏。
    # 这里只做当前入口的适用范围检查，不代表 CFD 的物理精度已经验证。
    cfg = read_json(cfd / '0-caseDict/caseDict')
    if cfg['flow']['speed'] != 50 or cfg['flow']['aoa'] != 0 or cfg['flow']['direction'] != [1, 0, 0] or cfg['flow']['rotors']:
        raise WorkflowError('简易入口用于 50 m/s、0°、+X、无旋翼工况。修改工况请使用详细教程并重新验证。')
    if [x['id'] for x in cfg['variants']] != [f'{i:02d}' for i in range(1, 11)]:
        raise WorkflowError('简易入口要求完整的 10 个方案。')
    if cfg['solver']['sampleEvery'] != 10 or cfg['solver']['convergenceWindow'] != 150:
        raise WorkflowError('简易入口使用原有的 10 次采样与 150 次窗口设置。')
    return cfg

def fingerprint(cfd):
    # 为几何、配置、宏和后处理记录 SHA-256；计算前复查，防止混用修改后的输入。
    # 注释也会改变文件哈希，因此修改已有批次脚本后应建立新批次。
    paths = [cfd / '0-caseDict/caseDict', cfd / '0-caseDict/solver.properties', *sorted((cfd / 'A-geo').glob('*.stl')), *sorted((cfd / 'UDF').glob('*.java')), cfd / 'UDF/run_fresh_batch.py', cfd / 'D-post/postprocess.py']
    return {str(p.relative_to(cfd)).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}

def open_file(path, no_open=False):
    # --no-open 用于命令检查与自动测试；正常使用时交给 Windows 默认程序打开 HTML。
    print('文件位置：' + str(path))
    if not no_open and os.name == 'nt':
        try:
            os.startfile(str(path))
        except OSError:
            print('未能自动打开，请双击上面的 HTML 文件。')

def generate(home, no_open=False):
    # 菜单 2：只做 FFD、几何验收、mm→m 转换和 STAR 命令预览，不求解流场。
    cfg = settings(home)
    print('\n正在生成原始机身和 10 组舱盖方案，本步骤不启动 CFD。')
    check_geometry(cfg)
    stamp = dt.datetime.now().strftime('批次_%Y%m%d_%H%M%S_%f')
    # 微秒时间戳让连续两次“生成模型”形成独立目录，旧结果不被覆盖。
    root = home / '结果' / stamp
    unpack_core(home / '_program/core.zip', root)
    cfd = root / 'cfd'
    contract(cfd)
    source_wsl = wsl_path(cfg, root / '程序')
    root_wsl = wsl_path(cfg, root)
    print('1/3 生成形状并检查几何……')
    # --units mm 是几何导出单位；内部 NPZ 中的坐标和位移同样保持毫米。
    child(wsl_args(cfg, [cfg['wsl_python'], source_wsl + '/ffd/run_ffd.py', '--config', source_wsl + '/ffd/configs/canopy_10.json', '--output', root_wsl + '/ffd_result', '--units', 'mm']), root / '日志/生成模型.log')
    ffd = read_json(root / 'ffd_result/run_manifest.json')
    # 只有状态完整、检查过交叉且包含十个方案，才继续生成 STAR 输入。
    if ffd['status'] != 'completed' or not ffd['intersectionsChecked'] or len(ffd['variants']) != 10:
        raise WorkflowError('FFD 检查状态不完整，暂不准备 STAR 输入。')
    print('2/3 自动转换为米，准备 STAR 输入……')
    # prepare_from_ffd.py 内部只转换一次 mm→m；这里不要手工再缩放 STL。
    child(wsl_args(cfg, [cfg['wsl_python'], source_wsl + '/prepare_from_ffd.py', '--ffd-run', root_wsl + '/ffd_result', '--cfd-root', root_wsl + '/cfd']), root / '日志/准备STAR输入.log')
    print('3/3 检查将要执行的批处理命令……')
    # --dry-run 打印宏路径与命令，不会启动 STAR 求解，也不能替代许可/API 验证。
    child([sys.executable, cfd / 'UDF/run_fresh_batch.py', '--root', cfd, '--star', cfg['star'], '--dry-run'], root / '日志/命令预览.log')
    state = {'run': stamp, 'projectHome': str(home), 'phase': '模型与STAR输入已准备_未计算CFD', 'inputHashes': fingerprint(cfd)}
    save_json(root / '批次状态.json', state)
    # 所有准备步骤完成后才更新“最近批次”，失败目录仍保留供排查。
    save_json(home / '结果/最近批次.json', {'run': stamp})
    print('\n模型生成完成，三维预览即将打开。看完后，选择 3 才会开始气动计算。')
    open_file(root / 'ffd_result/viewer.html', no_open)
    return root

def latest(home):
    # 读取最近成功准备的批次，并限制目录位于本项目的“结果”文件夹内。
    p = home / '结果/最近批次.json'
    if not p.exists():
        raise WorkflowError('还没有生成模型。请先选择菜单 2。')
    name = read_json(p).get('run', '')
    if not re.fullmatch(r'批次_\d{8}_\d{6}_\d{6}', name):
        raise WorkflowError('最近批次记录无效。请重新生成模型；已有结果会保留。')
    root = (home / '结果' / name).resolve()
    if not root.is_relative_to((home / '结果').resolve()) or not root.is_dir():
        raise WorkflowError('最近批次目录不存在。请重新生成模型。')
    return root

def validate_inputs(home, root):
    # 项目搬迁或输入改变后，旧批次不自动继续计算；重新生成以建立新的来源记录。
    state = read_json(root / '批次状态.json')
    if state['projectHome'] != str(home) or state['inputHashes'] != fingerprint(root / 'cfd'):
        raise WorkflowError('本批次位置或输入已改变。为避免混用旧结果，请选择 2 生成新批次。')
    return state

def case_finished(cfd, name, require_converged=True):
    # 最终 .sim 存在还不够：同时要求历史、收敛 JSON、正常完成日志。
    # 默认必须 converged=true；诊断报告可显式允许已运行但未收敛的变形方案。
    folder = cfd / 'C-run' / name
    required = ['final_result.sim', 'convergence.json', 'history.csv', 'batch.log']
    if not all((folder / x).is_file() for x in required):
        return False
    if 'VF_STAGE=CASE_COMPLETE' not in (folder / 'batch.log').read_text(encoding='utf-8', errors='replace'):
        return False
    conv = read_json(folder / 'convergence.json')
    return conv.get('converged') is True if require_converged else True

def report(home, root, cfg, no_open=False):
    # 只从真实已完成的 11 个算例汇总。基线未收敛或方案缺失时不生成完整排名。
    validate_inputs(home, root)
    cfd = root / 'cfd'
    if not case_finished(cfd, 'baseline'):
        raise WorkflowError('基线尚未完成或未收敛，当前只能查看模型。')
    missing = [x for x in CASES if not case_finished(cfd, x, require_converged=False)]
    if missing:
        raise WorkflowError('还有方案未完成，暂不生成完整对比报告：' + ', '.join(missing))
    cfd_wsl = wsl_path(cfg, cfd)
    print('正在生成图表和报告……')
    child(wsl_args(cfg, ['env', 'VF_POST_ROOT=' + cfd_wsl, cfg['wsl_python'], cfd_wsl + '/D-post/postprocess.py']), root / '日志/生成报告.log')
    # 后处理可能先写出图片再做一致性断言；child 正常退出后才承认报告检查通过。
    with (cfd / 'D-post/comparison.csv').open(encoding='utf-8-sig', newline='') as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 11:
        raise WorkflowError('对比表不是 11 个算例，不能认定完整报告已生成。')
    passed = all(case_finished(cfd, x) for x in CASES)
    # 区分全部收敛报告和含未收敛方案的诊断报告，避免把“算完”当作“有效”。
    save_json(root / '报告检查.json', {'postprocessExitCode': 0, 'cases': len(rows), 'allConverged': passed})
    state = read_json(root / '批次状态.json')
    state['phase'] = '报告已生成_全部满足收敛判据' if passed else '诊断报告已生成_存在未收敛方案'
    save_json(root / '批次状态.json', state)
    print('\n报告已生成。' if passed else '\n报告已生成，但含未收敛方案；请按诊断结果处理，不能据此确认优化有效。')
    open_file(cfd / 'E-report/results.html', no_open)

@contextmanager
def batch_lock(root):
    # 系统文件锁阻止两个窗口同时计算同一批次；进程结束后锁自动释放。
    # lock 文件保留并不表示仍在计算，是否占用由操作系统锁状态决定。
    path = root / '计算占用.lock'
    with path.open('a+b') as stream:
        if path.stat().st_size == 0:
            stream.write(b'0')
            stream.flush()
        stream.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as e:
            raise WorkflowError('这个批次正在另一个窗口计算，请回到原窗口查看。') from e
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == 'nt':
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)

def calculate(home, no_open=False):
    # 菜单 3 是实际求解入口，先取得批次锁，再检查输入与软件。
    cfg = settings(home)
    root = latest(home)
    with batch_lock(root):
        calculate_locked(home, root, cfg, no_open)

def calculate_locked(home, root, cfg, no_open=False):
    # 先计算基线；满足收敛和完成条件后，才继续默认 10 个方案。
    validate_inputs(home, root)
    cfd = root / 'cfd'
    contract(cfd)
    check_windows(cfg)
    check_star(cfg)
    print('\n开始实际 CFD：先计算原始机身，通过后再计算 10 组方案。')
    print('每个算例 4 个进程，逐个运行。请保留本窗口；详细进度在本批次日志里。')
    print('批次位置：' + str(root))
    common = [sys.executable, cfd / 'UDF/run_fresh_batch.py', '--root', cfd, '--star', cfg['star']]
    child([*common, '--cases', 'baseline'], root / '日志/计算基线.log', timeout=15000)
    # 原始 runner 会跳过已有输出，本层仍复查 converged，防止误用未收敛基线。
    if not case_finished(cfd, 'baseline'):
        raise WorkflowError('原始机身未通过收敛检查，已停止后续方案计算。请保留本批次日志并交给 AI 排查。')
    print('基线通过，正在计算 10 组方案……')
    child(common, root / '日志/计算全部方案.log', timeout=160000)
    # 全部计算退出后由同一批次的历史生成报告，不复制旧批次的数据。
    report(home, root, cfg, no_open)

def view(home, no_open=False):
    # 菜单 4 只打开最近结果；没有通过报告检查时，展示已有几何预览。
    root = latest(home)
    check = root / '报告检查.json'
    path = root / 'cfd/E-report/results.html'
    if check.is_file() and path.is_file():
        validate_inputs(home, root)
        if not read_json(check).get('allConverged'):
            print('此报告包含未收敛方案，属于诊断报告。')
        open_file(path, no_open)
    else:
        print('当前先查看几何模型；完成计算后会自动生成气动报告。')
        open_file(root / 'ffd_result/viewer.html', no_open)

def pick_file(title, filter_text):
    # 调用 Windows 自带文件选择窗口，软件路径作为数据传递，不作为脚本代码拼接。
    code = '[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.OpenFileDialog; $d.Title=$env:CANOPY_PICK_TITLE; $d.Filter=$env:CANOPY_PICK_FILTER; if($d.ShowDialog() -eq "OK"){[Console]::Write($d.FileName)}'
    env = dict(os.environ, CANOPY_PICK_TITLE=title, CANOPY_PICK_FILTER=filter_text)
    p = subprocess.run(['powershell.exe', '-NoProfile', '-STA', '-Command', code], capture_output=True, env=env)
    if p.returncode:
        raise WorkflowError('文件选择窗口没有打开，可让 AI 帮你填写 settings.json。')
    # PowerShell's stdout is redirected; explicitly request Unicode-friendly output below.
    return p.stdout.decode('utf-8-sig', errors='replace').strip()

def configure(home):
    # 菜单 5 把软件位置集中保存到 settings.json，不修改系统 PATH 或全局安装。
    cfg = read_json(home / 'settings.json')
    print('\n软件位置只需设置一次。项目路径由程序自动识别。')
    print('1 选择 Windows Python\n2 选择 STAR 启动文件\n3 修改 WSL Python\n4 修改 WSL 发行版\n0 返回')
    choice = input('请选择：').strip()
    if choice == '1':
        value = pick_file('选择实际的 python.exe', 'Python (python.exe)|python.exe|Executable (*.exe)|*.exe')
        if value:cfg['windows_python'] = value
    elif choice == '2':
        value = pick_file('选择 STAR 的 starccm+.bat', 'STAR launcher (*.bat;*.exe)|*.bat;*.exe|All files (*.*)|*.*')
        if value:cfg['star'] = value
    elif choice in ['3', '4']:
        key = 'wsl_python' if choice == '3' else 'wsl_distro'
        print('当前值：' + cfg[key])
        value = input('填写新值（直接回车保留）：').strip().strip('"')
        if value:cfg[key] = value
    elif choice == '0':
        return
    else:
        print('请选择上面的数字。')
        return
    save_json(home / 'settings.json', cfg)
    print('设置已保存。若修改了 Windows Python，关闭窗口后重新双击“开始使用.cmd”。')

def menu(home, no_open=False):
    # 数字与动作的唯一映射：1检查、2几何、3求解、4查看、5设置。
    actions = {'1': check_environment, '2': lambda p:generate(p, no_open), '3':lambda p:calculate(p, no_open), '4':lambda p:view(p, no_open), '5':configure}
    while True:
        print('\n' + '=' * 50)
        print('舱盖 FFD + STAR 简易入口｜50 m/s，0°')
        print('1  检查电脑\n2  生成 10 组模型，并打开预览\n3  开始气动计算，并生成报告（会启动 STAR）\n4  查看最近结果\n5  设置软件位置\n0  退出')
        print('=' * 50)
        choice = input('输入数字后按回车：').strip()
        if choice == '0':return
        if choice not in actions:
            print('请选择 0—5。')
            continue
        try:
            actions[choice](home)
        except (WorkflowError, OSError, ValueError, KeyError) as e:
            print('\n[没有完成]\n' + str(e))
            print('已有模型和结果均已保留。把这段提示和日志交给 AI 即可排查。')
        input('\n按回车返回菜单……')

def main():
    # CLI 参数也供测试使用；普通使用者直接双击 CMD，不必输入这些参数。
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--home', type=Path, required=True)
    parser.add_argument('--action', choices=['menu','check','generate','calculate','view','settings'], default='menu')
    parser.add_argument('--no-open', action='store_true')
    args = parser.parse_args()
    home = args.home.resolve()
    if os.name != 'nt':
        raise WorkflowError('请在 Windows 双击“开始使用.cmd”，WSL 由入口自动调用。')
    if args.action == 'menu':menu(home, args.no_open)
    elif args.action == 'check':check_environment(home)
    elif args.action == 'generate':generate(home, args.no_open)
    elif args.action == 'calculate':calculate(home, args.no_open)
    elif args.action == 'view':view(home, args.no_open)
    else:configure(home)

if __name__ == '__main__':
    try:
        main()
    except (WorkflowError, OSError, ValueError, KeyError) as exc:
        print('\n[没有完成]\n' + str(exc), file=sys.stderr)
        raise SystemExit(1)
