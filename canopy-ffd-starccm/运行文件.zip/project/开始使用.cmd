@echo off
REM Keep settings local to this command window.
setlocal
REM Use UTF-8 for the Chinese menu and Python messages.
chcp 65001 >nul
set "PYTHONUTF8=1"
REM The project root comes from this CMD file; no fixed project path is required.
set "CANOPY_HOME=%~dp0"
REM Read settings.json, select Python if missing, then open the menu in start.py.
powershell.exe -NoProfile -STA -Command "[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false); $ErrorActionPreference='Stop'; try { $root=[IO.Path]::GetFullPath((Join-Path $env:CANOPY_HOME '.')); $cfgPath=Join-Path $root 'settings.json'; $cfg=Get-Content -LiteralPath $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json; $py=$cfg.windows_python; if(-not (Test-Path -LiteralPath $py -PathType Leaf)){ Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.OpenFileDialog; $d.Title='Select a working python.exe'; $d.Filter='Python (python.exe)|python.exe|Executable (*.exe)|*.exe'; if($d.ShowDialog() -ne 'OK'){exit 1}; $py=$d.FileName; $cfg.windows_python=$py; $cfg | ConvertTo-Json | Set-Content -LiteralPath $cfgPath -Encoding UTF8 }; & $py (Join-Path $root '_program\start.py') --home $root; exit $LASTEXITCODE } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 pause
endlocal
