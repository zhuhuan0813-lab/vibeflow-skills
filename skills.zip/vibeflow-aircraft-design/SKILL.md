---
name: vibeflow-aircraft-design
description: Use when defining, sizing, laying out, modeling, analyzing, optimizing, or validating aircraft and aerodynamic concepts in VibeFlow/VibeCAE, including mission and design requirements, fixed-wing/UAV/eVTOL configuration decisions, OpenVSP .vsp3 parametric geometry, VSPAERO sweeps, parasite drag, weight and center-of-gravity work, static and dynamic stability, control surfaces, multidisciplinary optimization, uncertainty, and multi-fidelity handoff to SU2, OpenFOAM, Fluent, STAR-CCM+, structural solvers, or test data.
---

# VibeFlow Aircraft Design

Use this skill to turn aircraft intent into a traceable design process. Treat OpenVSP as the parametric geometry and preliminary-analysis backend, VSPAERO as a potential-flow aerodynamic backend, and higher-fidelity solvers or experiments as validation layers.

## 使用边界

只执行用户请求范围内的工作。下文流程、产物和验证按当前模式及实际依赖选用，参考资料按需读取；转交其他 Skill 表示继续处理依赖，不表示停止。阶段验收不新增审批；已有授权持续有效。纯诊断和局部修改不要求完成整套建模、求解、报告或重建目录。

## Establish The Design Contract

1. Read `0-caseDict/caseDict` before creating geometry or running analysis.
2. Identify the vehicle class, mission, certification or research context, operating environment, payload, range/endurance, speed envelope, altitude envelope, field or launch constraints, propulsion assumptions, and design objectives.
3. Separate user requirements, derived requirements, assumptions, constraints, targets, and margins. Never present an assumption as a requirement.
4. Record units and coordinate conventions. Use one internal unit system and convert only at interfaces.
5. Define the current fidelity level and the decisions it is allowed to support.
6. Stop and request missing requirements when they materially affect topology, sizing, stability, propulsion, loads, or safety.

Read `references/aircraft-design-methodology.md` for the complete requirements, sizing, layout, weight, stability, optimization, and validation process.

## Read The Toolchain Before Execution

Read the Setup context and verify:

- `cae.openvsp`: OpenVSP GUI entry or installation-resolved executable.
- `cae.openvspVersion`: detected OpenVSP release.
- `cae.openvspScript`: headless `vspscript` executable.
- `cae.openvspPython` and `cae.openvspPythonModule`: compatible Windows Python and API status.
- `cae.vspaero`: VSPAERO solver executable.

Use `vibeflow-toolchain` when any entry is missing, the Python binding has an ABI mismatch, or VSPAERO cannot be found. Read `references/openvsp-vspaero-playbook.md` before writing OpenVSP API scripts, changing .vsp3 models, exporting geometry, or running VSPAERO.

## Preserve Sources Of Truth

- Keep `caseDict` as the source of physical and design intent.
- Treat `.vsp3` files, DegenGeom files, solver inputs, and result databases as generated or imported artifacts.
- Never silently reverse-engineer a user-edited `.vsp3` into `caseDict`. Produce an explicit import report and ask before replacing source parameters.
- Never overwrite a user-supplied model. Copy it into a versioned working directory.
- Name components, sets, subsurfaces, control surfaces, and exports deterministically.

## Recommended Artifact Layout

```text
A-geo/openvsp/
+-- scripts/
+-- models/
+-- exports/
+-- degen/
+-- manifests/
|
C-run/vspaero/case-1/
+-- input/
+-- run/
+-- logs/
+-- results/
+-- manifest.json
|
D-post/aircraft/
+-- scripts/
+-- data/
+-- figures/
+-- validation/
+-- design-summary.md
```

Use unique run directories and model basenames. VSPAERO reruns can overwrite files with the same basename.

## Execute The Design Workflow

### 1. Requirements And Design Points

- Convert mission statements into measurable design points and off-design checks.
- Define atmosphere, Mach, Reynolds number, angle of attack, sideslip, load factor, mass state, control state, and propulsion state for every analysis point.
- Define objective functions, hard constraints, soft targets, margins, and acceptance evidence.
- Record which requirements remain unverified.

### 2. Architecture And Preliminary Sizing

- Compare plausible configurations before committing to geometry.
- Size wing loading, thrust-to-weight or power-to-weight, reference area, span, aspect ratio, tail volumes, control authority, and propulsion placement from requirements.
- Check packaging, ground clearance, propeller/rotor clearance, visibility where relevant, and maintainability.
- Reject configurations that violate fundamental mission, packaging, balance, or control constraints.

### 3. Parametric OpenVSP Layout

- Build components from stable engineering parameters and names.
- Create wings, fuselages, tails, nacelles, pods, propellers/rotors, landing gear, control surfaces, and component sets only when required.
- Apply transformations and symmetry deliberately; verify global axes and moments.
- Save a native `.vsp3` model, a parameter manifest, and preview exports.
- Run geometry checks for wetted area, projected area, volume, mass properties, interference, and clearance as applicable.

### 4. Aerodynamic Analysis

- Use VSPAERO for potential-flow forces, moments, span loading, stability derivatives, and selected unsteady or propeller/rotor analyses.
- Use the OpenVSP Parasite Drag analysis for a traceable viscous drag buildup where applicable.
- Define reference area, span, chord, moment center, wake settings, tessellation, symmetry, and analysis method explicitly.
- Perform discretization and wake-sensitivity checks before trusting trends.
- Do not use VSPAERO alone to validate separated flow, stall, boundary-layer transition, complex viscous interference, or shock-dominated transonic behavior.

### 5. Weight, Balance, And Inertia

- Maintain a component mass statement with source, basis, uncertainty, location, and growth allowance.
- Evaluate empty, payload, fuel/battery, and mission-segment mass states.
- Compute center-of-gravity and inertia tensors for all critical loading cases.
- Compare the CG envelope with aerodynamic-center/neutral-point estimates and control-authority limits.
- Never use geometry volume as mass without an explicit density and equipment allocation model.

### 6. Stability And Control

- Evaluate longitudinal, lateral, and directional static stability across the operating envelope.
- Evaluate trim, control deflection, hinge or actuator limits, and control power.
- Check dynamic modes only with a documented mass/inertia model and derivative provenance.
- Preserve sign conventions and reference quantities with every derivative table.
- Escalate to higher fidelity or test evidence when propulsive coupling, nonlinear aerodynamics, or separated flow controls stability.

### 7. Optimization

- Define design variables, bounds, discrete choices, objectives, constraints, fidelity, and failure penalties before launching a study.
- Start with screening and design-of-experiments; optimize only after sensitivity and model-quality checks.
- Cache evaluations by input hash and keep every failed design with its failure category.
- Validate the optimum against neighboring points, alternative starts, tighter discretization, and at least one higher-fidelity method.
- Prefer robust or margin-aware designs over fragile point optima.

### 8. Multi-Fidelity Validation

- Use analytic and handbook methods as Level 0 checks.
- Use OpenVSP geometry analyses, parasite drag, and VSPAERO as Level 1 preliminary methods.
- Use SU2, OpenFOAM, Fluent, or STAR-CCM+ as Level 2 aerodynamic validation where viscous or compressible physics matter.
- Use CalculiX, Abaqus, or another structural backend for load-path, stiffness, stress, and aeroelastic risk checks.
- Use wind-tunnel, flight-test, manufacturer, or published data as Level 3 evidence when available.
- Quantify disagreement, uncertainty, and decision impact instead of selecting the most favorable result.

## OpenVSP Execution Rules

- Use headless Python with `LOAD_GRAPHICS = False` when reproducible batch generation, DOE, or optimization is the priority.
- Use `vspscript` when the packaged Python API is unavailable or its ABI does not match.
- OpenVSP GUI operation is allowed for interactive layout, visual inspection, manual geometry editing, analysis setup discovery, and user-guided review. After GUI changes, save the `.vsp3` model and record which components, parameters, sets, and analyses were changed.
- For repeated or production workflows, convert stable GUI-discovered steps back into API or `vspscript` instructions when practical.
- Discover API parameters and analysis inputs from the installed release. Do not assume names from another release.
- Call `SetVSPAEROPath` when Python cannot locate VSPAERO beside its interpreter.
- Check the OpenVSP API error stack, process exit code, expected files, and result identifiers after every stage.
- Keep API scripts idempotent: clear or load a known model, set all controlled parameters, update, validate, then save.

## Evidence And Reporting

Record for every candidate:

- Requirement and assumption revision.
- Geometry parameter vector and `.vsp3` hash.
- Tool versions, commands, scripts, and environment.
- Reference quantities and coordinate/sign conventions.
- Mass state, CG, inertia, atmosphere, and operating point.
- Mesh/tessellation/wake settings and convergence evidence.
- Aerodynamic coefficients, loads, stability metrics, constraints, and margins.
- Fidelity level, uncertainty, validation comparisons, failures, and unresolved risks.

Update `caseDict` workflow state only after the current gate is satisfied.

## Acceptance Gates

- Requirements are measurable and traceable to analysis points.
- Geometry rebuilds through the selected OpenVSP path, GUI-assisted or headless, and exports without unresolved API errors.
- Component names, sets, control surfaces, and reference quantities are stable.
- Weight, CG, and inertia cover critical loading states.
- Aerodynamic trends pass discretization and physical sanity checks.
- Static stability, trim, and control authority satisfy stated margins.
- Optimization results are reproducible and revalidated near the selected design.
- High-consequence conclusions have independent higher-fidelity or experimental support.
- All limitations and unsupported decisions are explicit.

## Failure Routing

- Missing executable, API import, or VSPAERO path: use `vibeflow-toolchain`.
- Missing mission or design requirement: return to `vibeflow-case-dict`.
- Invalid or non-rebuildable geometry: return to OpenVSP layout and geometry validation.
- VSPAERO divergence or implausible loads: inspect geometry, references, wake, tessellation, operating point, and method before changing requirements.
- Viscous, separated, transonic, or aeroelastic uncertainty: escalate fidelity.
- Inadequate evidence: do not force a design recommendation or final report.
