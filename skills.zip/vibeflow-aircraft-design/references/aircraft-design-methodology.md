# Aircraft Design Methodology

## Contents

1. Scope and fidelity
2. Requirements and mission definition
3. Configuration selection
4. Preliminary sizing
5. Geometry and layout
6. Aerodynamics
7. Weight, CG, and inertia
8. Stability and control
9. Propulsion integration
10. Structures and loads
11. Optimization
12. Multi-fidelity validation
13. Deliverables and review gates

## 1. Scope And Fidelity

Treat aircraft design as a coupled requirements, geometry, aerodynamics, propulsion, mass, stability, structures, operations, and validation problem. Do not let a convenient tool define the problem.

Classify each result:

| Level | Typical methods | Appropriate decisions |
| --- | --- | --- |
| 0 | Algebraic sizing, handbook correlations, historical data | Feasibility, order-of-magnitude sizing |
| 1 | OpenVSP, parasite drag, VSPAERO, reduced-order models | Configuration trades, preliminary layout, trend studies |
| 2 | RANS CFD, nonlinear structural FEA, propulsion maps | Selected design verification, local loads, nonlinear effects |
| 3 | Wind tunnel, rig, flight test, certified/vendor data | Validation and high-consequence decisions |

Always record the fidelity level, assumptions, calibration range, uncertainty, and decisions that the result may support.

## 2. Requirements And Mission Definition

Create a requirement table with these fields:

| Field | Meaning |
| --- | --- |
| ID | Stable requirement identifier |
| Statement | Measurable requirement |
| Source | User, regulation, mission study, interface, or assumption |
| Type | Hard constraint, target, objective, or derived requirement |
| Units | Explicit units |
| Verification | Analysis, inspection, test, or demonstration |
| Margin | Required margin and basis |
| Status | Open, assumed, analyzed, verified, or failed |

Define at least:

- Vehicle class and operational concept.
- Payload mass, volume, location, interfaces, and environmental needs.
- Range, endurance, loiter, dash, climb, ceiling, takeoff/landing, launch/recovery, and reserve policy.
- Speed, Mach, Reynolds, altitude, temperature, wind, gust, and precipitation envelopes.
- Runway, catapult, hand launch, VTOL, shipboard, or ground-handling constraints.
- Propulsion architecture, energy source, fuel/battery reserve, and thermal constraints.
- Crew, autonomy, communications, sensors, and safety constraints.
- Manufacturing, transport, storage, maintenance, cost, noise, and emissions constraints.
- Certification basis or explicit statement that the study is non-certification research.

Break the mission into segments. For each segment record duration or distance, altitude, speed, load factor, mass state, propulsion state, and energy/fuel change. Define a small set of design points and a larger set of verification points.

## 3. Configuration Selection

Compare configurations using the same requirement set and fidelity. Include conventional, canard, tailless, joined-wing, distributed-propulsion, rotorcraft, or eVTOL options only when plausible.

Score at least:

- Mission feasibility and energy efficiency.
- Aerodynamic efficiency and expected off-design behavior.
- Stability and control complexity.
- Propulsion-airframe interaction.
- Structural load path and aeroelastic risk.
- Packaging, payload access, landing gear, ground clearance, and maintainability.
- Manufacturing and integration complexity.
- Noise, safety, redundancy, and failure containment.
- Availability and credibility of analysis methods.

Eliminate a topology only with a recorded reason. Do not optimize detailed parameters before the topology survives first-order feasibility checks.

## 4. Preliminary Sizing

### Atmosphere And Dynamic Pressure

Use a documented atmosphere model and keep dimensional values with each point.

$$q = \frac{1}{2}\rho V^2$$

$$Re = \frac{\rho V c}{\mu}$$

Use local chord for sectional Reynolds number and mean aerodynamic chord for a vehicle-level reference only when appropriate.

### Wing Loading

Relate stall speed, weight, area, and maximum lift coefficient:

$$V_s = \sqrt{\frac{2W}{\rho S C_{L,\max}}}$$

Evaluate wing loading constraints at the correct mass state and atmospheric condition. Include takeoff/landing assumptions, gust and maneuver loads, and high-altitude lift requirements.

### Thrust Or Power Loading

Use thrust-to-weight for thrust-producing systems and power-to-weight or disk loading where more appropriate. Evaluate takeoff, climb, ceiling, acceleration, cruise, one-engine-inoperative or degraded modes, and thermal limits.

Do not use a single scalar thrust-to-weight ratio across a wide speed range without a propulsion model. Use thrust or power available as a function of speed, altitude, state of charge, temperature, and installation loss.

### Basic Aerodynamic Relations

$$L = q S C_L$$

$$D = q S C_D$$

Use a parabolic drag polar only inside its justified range:

$$C_D = C_{D0} + k C_L^2$$

$$k = \frac{1}{\pi e AR}$$

Treat Oswald efficiency `e` as a calibrated model input, not a universal constant. Separate parasite, induced, wave, trim, cooling, excrescence, and installation drag.

### Tail Volume Starting Points

Use tail volume coefficients only as starting estimates:

$$V_H = \frac{S_H l_H}{S_W \bar{c}}$$

$$V_V = \frac{S_V l_V}{S_W b}$$

Then verify neutral point, trim, control authority, dynamic modes, downwash, propulsive effects, and nonlinear limits.

### Mission Performance

Use Breguet relations only when their assumptions fit the propulsion and mission segment. For electric aircraft, integrate power and energy over the mission rather than forcing a fuel-fraction model.

For every sizing equation, record the source, validity range, correction factors, and uncertainty.

## 5. Geometry And Layout

Define a global aircraft coordinate system and a separate aerodynamic sign convention. Record origin, positive axes, rotation order, and moment reference.

Parameterize:

- Wing area, span, aspect ratio, taper, sweep reference, dihedral, twist, airfoils, thickness, incidence, control surfaces, and segmentation.
- Fuselage length, cross-sections, lofting, cabin/payload envelope, nose/tail closure, and internal volume.
- Horizontal/vertical tails or equivalent control surfaces, moment arms, incidence, sweep, taper, and control geometry.
- Nacelles, inlets, exhausts, pylons, pods, antennas, sensors, and excrescences.
- Propellers/rotors, radius, hub, blade count, axis, rotation direction, disk clearance, and interaction zones.
- Landing gear, wheelbase, track, retraction envelope, tip-back/tip-over, tail/wing strike, and ground clearance.

Use stable component names and sets. Preserve separate aerodynamic, structural, packaging, and export sets. Check:

- Intersections and unintended gaps.
- Wetted and projected area.
- Internal volume and payload fit.
- Control-surface hinge continuity and deflection clearance.
- Propeller/rotor, ground, fuselage, and tail clearance.
- Reference area/span/chord consistency.
- Symmetry and duplicated components.
- Surface orientation and export watertightness.

## 6. Aerodynamics

Build an analysis matrix rather than one design point:

| Variable | Typical purpose |
| --- | --- |
| Angle of attack | Lift curve, trim, stall-risk trend |
| Sideslip | Directional/lateral derivatives |
| Mach | Compressibility and wave-drag risk |
| Reynolds number | Skin friction and transition sensitivity |
| Control deflection | Trim and control power |
| Propulsion state | Slipstream and installation effects |
| Ground height | Ground-effect and clearance studies |
| Mass/CG state | Required lift and trim |

For VSPAERO:

- Choose VLM for thin lifting-surface trend studies.
- Choose panel or hybrid representations when body thickness and pressure distributions matter and the geometry is suitable.
- Run chord/span tessellation and wake sensitivity studies.
- Verify reference quantities and moment center before comparing coefficients.
- Compare integrated loads with sectional/spanwise distributions.
- Use stability derivatives only with documented perturbation settings and signs.

For parasite drag:

- Record skin-friction correlation, laminar fraction or transition assumption, form factors, interference, roughness, excrescences, cooling, leakage, and protuberances.
- Keep induced and parasite drag accounting separate to prevent double counting.
- Calibrate against relevant data where possible.

Escalate to viscous CFD when separation, high lift, propulsion interaction, cooling flow, transonic shocks, inlet/exhaust flow, bluff bodies, or local loads drive the decision.

## 7. Weight, CG, And Inertia

Maintain a mass statement:

| Item | Mass | X/Y/Z | Inertia basis | Source | Uncertainty | Growth |
| --- | ---: | ---: | --- | --- | ---: | ---: |

Calculate total mass and CG:

$$m = \sum_i m_i$$

$$\mathbf{r}_{cg} = \frac{\sum_i m_i\mathbf{r}_i}{\sum_i m_i}$$

Use the parallel-axis theorem when combining inertia tensors:

$$\mathbf{I}_O = \mathbf{I}_{cg} + m\left[(\mathbf{d}\cdot\mathbf{d})\mathbf{1} - \mathbf{d}\mathbf{d}^T\right]$$

Evaluate at least:

- Operating empty.
- Maximum payload and forward/aft payload.
- Full and minimum fuel or battery.
- Critical mission segments.
- Degraded or jettison states where applicable.

Apply technology readiness, estimation uncertainty, and growth allowances separately. Do not hide margin inside component estimates.

## 8. Stability And Control

### Static Margin

Use a consistent reference:

$$SM = \frac{x_{np} - x_{cg}}{\bar{c}}$$

Positive static margin normally indicates longitudinal static stability under the selected convention, but acceptable margin depends on vehicle type, control law, mission, and maneuverability goals.

Check:

- `C_{m_\alpha}`, `C_{n_\beta}`, and lateral stability signs using the declared convention.
- Trim angle of attack and control deflection across CG and speed envelopes.
- Elevator/canard/elevon, aileron/spoiler, and rudder authority.
- Control hinge/actuator loads and rate limits at relevant dynamic pressure.
- Takeoff rotation, landing flare, crosswind, engine-out/degraded thrust, and gust cases as applicable.
- Propeller/rotor gyroscopic and slipstream effects when important.

Dynamic stability requires dimensional derivatives, mass, inertia, flight condition, and equations of motion. Report short-period, phugoid, Dutch-roll, roll, and spiral characteristics only when those inputs are credible.

## 9. Propulsion Integration

Treat installed propulsion, not isolated thrust, as the design variable. Record:

- Propulsor maps or thrust/power models.
- Inlet, exhaust, pylon, nacelle, cooling, and electrical losses.
- Propeller/rotor disk location, axis, rotation, swirl, slipstream contraction, and ground clearance.
- Fuel/battery mass and CG evolution.
- Thermal derating and transient limits.
- Noise, blade-tip Mach, structural, and containment constraints.
- Failure cases and control implications.

Use actuator-disk models for early coupling trends. Use blade-resolved or higher-fidelity methods when loading, noise, unsteadiness, or interference controls the design.

## 10. Structures And Loads

Define a preliminary load envelope before structural sizing:

- Positive/negative maneuver.
- Gust.
- Landing and ground handling.
- Control and propulsion loads.
- Pressurization.
- Thermal and acoustic loads.
- Rotor/propeller imbalance and gyroscopic loads.
- Emergency, crash, or hard-landing cases when required.

Map aerodynamic loads with conserved force and moment. Check deformation impact on aerodynamic shape and control clearance. Escalate to aeroelastic analysis when flexibility changes trim, stability, loads, or flutter margin.

## 11. Optimization

Define the mathematical problem explicitly:

$$\min_{\mathbf{x}} f(\mathbf{x})$$

$$g_j(\mathbf{x}) \le 0,\quad h_k(\mathbf{x}) = 0,\quad \mathbf{x}_L \le \mathbf{x} \le \mathbf{x}_U$$

Classify variables as continuous, integer, categorical, or topology choices. Include geometry, mass, aerodynamic, stability, structural, propulsion, mission, manufacturing, and operational constraints.

Use this sequence:

1. Verify baseline reproducibility.
2. Screen variables and remove inactive or redundant dimensions.
3. Run a space-filling DOE and inspect failures/discontinuities.
4. Calibrate surrogates only with cross-validation and domain checks.
5. Optimize with multiple starts or population methods as appropriate.
6. Re-evaluate the selected point with the original model.
7. Check neighboring points and tighter numerical settings.
8. Validate with higher fidelity.
9. Perform uncertainty and margin analysis.

Never reward failed solver evaluations with deceptively favorable values. Use explicit failure penalties and classify the cause.

## 12. Multi-Fidelity Validation

Create a validation matrix:

| Quantity | Low fidelity | Higher fidelity | Data/test | Acceptance |
| --- | --- | --- | --- | --- |
| Lift curve | VSPAERO | RANS CFD | tunnel/flight | slope and offset tolerance |
| Drag polar | parasite + VSPAERO | viscous CFD | tunnel/flight | component and total tolerance |
| Pitch moment | VSPAERO | viscous CFD | tunnel/flight | trim and slope tolerance |
| Span load | VSPAERO | CFD/loads | strain/pressure | load distribution tolerance |
| CG/inertia | mass model | detailed CAD/FEA | weigh/swing test | mass-property tolerance |

Use discrepancy to update uncertainty, not merely to tune until plots overlap. Preserve both pre-calibration and post-calibration results.

## 13. Deliverables And Review Gates

Deliver:

- Requirement and assumption matrix.
- Mission/design-point table.
- Configuration trade and selection rationale.
- Parameterized geometry with rebuild script and manifest.
- Mass, CG, inertia, and margin statement.
- Aerodynamic polars, loads, convergence/sensitivity, and drag buildup.
- Stability, trim, and control-authority evidence.
- Optimization definition, history, failures, and robustness checks.
- Multi-fidelity comparison and uncertainty.
- Risk register, unresolved questions, and recommended next tests.

Do not pass a gate when a missing input could reverse the design decision.
