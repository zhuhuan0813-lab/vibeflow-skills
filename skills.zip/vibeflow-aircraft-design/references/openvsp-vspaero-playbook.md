# OpenVSP And VSPAERO Playbook

## Contents

1. Official references
2. VibeFlow configuration
3. Execution modes
4. Recommended layout
5. Python API startup
6. Parametric modeling
7. Geometry checks and export
8. VSPAERO setup and execution
9. Results and post-processing
10. Parameter studies and optimization
11. High-fidelity handoff
12. Failure diagnosis
13. Completion checklist

## 1. Official References

- OpenVSP home and downloads: https://openvsp.org/
- OpenVSP documentation hub: https://openvsp.org/docs.shtml
- C++ / AngelScript API: https://openvsp.org/api_docs/latest/
- Python API: https://openvsp.org/pyapi_docs/latest/
- Python loading modes: https://openvsp.org/pyapi_docs/latest/openvsp_config.html
- NASA VSPAERO basics: https://www.nasa.gov/reference/openvsp-vspaero-basics/
- Official source repository: https://github.com/OpenVSP/OpenVSP

Use documentation matching the installed release. OpenVSP and VSPAERO analysis inputs can change between releases, especially across major VSPAERO updates.

## 2. VibeFlow Configuration

| Key | Meaning |
| --- | --- |
| `cae.openvsp` | Resolved `vsp` executable |
| `cae.openvspVersion` | Setup-detected version |
| `cae.openvspScript` | Headless `vspscript` executable |
| `cae.openvspPython` | Windows Python selected for the API |
| `cae.openvspPythonModule` | Whether headless `import openvsp` succeeded |
| `cae.vspaero` | VSPAERO solver executable |

Environment aliases, when provided by the launcher:

```text
VIBEFLOW_OPENVSP
VIBEFLOW_OPENVSP_SCRIPT
VIBEFLOW_OPENVSP_PYTHON
VIBEFLOW_VSPAERO
```

The OpenVSP Python module is a compiled binding. The Python major/minor version and architecture must match the OpenVSP distribution. A working `vspscript` is the preferred fallback when the API ABI does not match.

## 3. Execution Modes

### Headless Python

Use for structured generation, analysis, result extraction, DOE, and optimization. Explicitly disable graphics before importing `openvsp`.

### AngelScript

Use `.vspscript` files through the `vspscript` executable when Python bindings are unavailable. The AngelScript API maps closely to the C++ API and avoids Python ABI coupling.

### Direct VSPAERO Command Line

Use for advanced inputs not exposed by the current OpenVSP GUI/API, scheduler integration, and repeat runs from generated geometry. Generate a known-good baseline through OpenVSP first, then inspect the installed VSPAERO help and input files before changing advanced options.

### GUI

Use the GUI when interactive layout, parameter discovery, visual inspection, manual geometry edits, or user-guided analysis setup make the work clearer or safer. Save the `.vsp3` after GUI changes, record the edited components and parameters, and mirror stable GUI-discovered steps into scripts when practical.

## 4. Recommended Layout

```text
A-geo/openvsp/
+-- scripts/build_aircraft.py
+-- scripts/export_aircraft.py
+-- models/baseline.vsp3
+-- models/candidate-<id>.vsp3
+-- exports/preview.step
+-- exports/preview.stl
+-- exports/cfd/
+-- degen/
+-- manifests/baseline.json
|
C-run/vspaero/case-<id>/
+-- input/
+-- run/
+-- logs/
+-- results/raw/
+-- results/tables/
+-- manifest.json
|
D-post/aircraft/
+-- scripts/plot_polars.py
+-- data/
+-- figures/
+-- validation/
```

Use a new basename or run directory for every design point. Preserve inputs and raw outputs before post-processing.

## 5. Python API Startup

Use this import order:

```python
import openvsp_config

openvsp_config.LOAD_GRAPHICS = False
openvsp_config.LOAD_FACADE = False

import openvsp as vsp

print(vsp.GetVSPVersion())
```

If VSPAERO is not beside the Python interpreter, set its directory:

```python
from pathlib import Path

vspaero_exe = Path(r"C:\path\to\OpenVSP\vspaero.exe")
if not vsp.CheckForVSPAERO(str(vspaero_exe.parent)):
    raise RuntimeError(f"VSPAERO not found in {vspaero_exe.parent}")
if not vsp.SetVSPAEROPath(str(vspaero_exe.parent)):
    raise RuntimeError("OpenVSP rejected the VSPAERO path")
```

At script start, either clear the model or load an explicit input. Do not depend on process memory from a prior run.

```python
vsp.ClearVSPModel()
# Or:
# vsp.ReadVSPFile(str(input_model))
```

At each stage, drain the API error stack:

```python
def collect_vsp_errors():
    errors = []
    while vsp.GetNumTotalErrors() > 0:
        err = vsp.PopLastError()
        errors.append(err.GetErrorString())
    return errors
```

Treat any unexpected error as a failed stage even if a file was written.

## 6. Parametric Modeling

### Component Creation

Create a component, name it immediately, set all controlled parameters, then update:

```python
wing_id = vsp.AddGeom("WING")
if not wing_id:
    raise RuntimeError("Could not create main wing")

vsp.SetGeomName(wing_id, "MainWing")
vsp.SetParmValUpdate(wing_id, "TotalArea", "WingGeom", 16.0)
vsp.SetParmValUpdate(wing_id, "X_Rel_Location", "XForm", 2.5)
vsp.Update()
```

Parameter names and groups are release and geometry-type specific. Before setting production values:

1. Query geometry types with `GetGeomTypes`.
2. Query containers and parameters with `FindContainer`, `FindParm`, and parameter-name/group APIs.
3. Check every returned ID.
4. Use the installed API docs or a model created with the same release.
5. Record parameter IDs/names and units in the manifest.

### Wings And Airfoils

Control planform through area/span/aspect-ratio drivers, section span/chord/taper, sweep reference, dihedral, twist, and tessellation. Control airfoils through XSec APIs:

- Obtain the wing XSecSurf.
- Enumerate XSecs.
- Change XSec shape only when required.
- Set airfoil family/file, thickness, camber, and chordwise resolution.
- Verify root-to-tip section ordering.
- Export airfoil coordinates for independent checking.

Do not combine incompatible wing drivers. Read back area, span, aspect ratio, and mean aerodynamic chord after updating.

### Fuselages, Pods, And Nacelles

Control cross-section locations, dimensions, shapes, rotations, and skinning. Avoid nearly coincident sections and abrupt curvature without validation. Check volume, wetted area, closure, and export quality.

### Control Surfaces

Create control surfaces as named subsurfaces. Record:

- Parent geometry.
- Spanwise start/end.
- Chord fraction or hinge definition.
- Hinge axis and sign convention.
- Deflection limits.
- VSPAERO control-surface group.

Use the VSPAERO control-surface group API to create groups and set gains. Verify that the expected surfaces appear in each group before stability or trim studies.

### Propellers And Rotors

Define radius, hub, blade count, axis, rotation direction, RPM, blade sections, chord/twist curves, and operating mode. Distinguish:

- Geometry only.
- Actuator-disk approximation.
- Blade-resolved/unsteady VSPAERO.
- High-fidelity rotating/sliding mesh CFD.

Confirm thrust-vector direction and rotation sign with a lightweight test.

### Sets, Modes, And Presets

Use named Sets to separate analysis/export components. Use Variable Presets or Modes for reusable configurations such as clean, takeoff, landing, control deflections, landing gear, and propulsion states.

Do not depend on transient GUI visibility as the analysis definition.

### Saving

```python
from pathlib import Path

output_model = Path("A-geo/openvsp/models/baseline.vsp3")
output_model.parent.mkdir(parents=True, exist_ok=True)
vsp.SetVSP3FileName(str(output_model))
vsp.WriteVSPFile(str(output_model), vsp.SET_ALL)
```

Check that the file exists, is nonempty, reopens in a fresh process, and reproduces expected component counts and parameters.

## 7. Geometry Checks And Export

### Analysis Manager Discovery

Never assume an analysis input schema:

```python
analysis_name = "CompGeom"
available = set(vsp.ListAnalysis())
if analysis_name not in available:
    raise RuntimeError(f"{analysis_name} unavailable; found {sorted(available)}")

vsp.SetAnalysisInputDefaults(analysis_name)
print(vsp.GetAnalysisInputNames(analysis_name))
vsp.PrintAnalysisInputs(analysis_name)
result_id = vsp.ExecAnalysis(analysis_name)
if not result_id:
    raise RuntimeError("CompGeom returned no result ID")
```

Use geometry analyses for:

- CompGeom and wetted area/volume.
- Mass properties with explicit density/mass assumptions.
- Projected area and planar slices.
- Interference and clearance checks.
- DegenGeom for aerodynamic handoff.

### DegenGeom

```python
degen_csv = "A-geo/openvsp/degen/baseline_DegenGeom.csv"
vsp.SetComputationFileName(vsp.DEGEN_GEOM_CSV_TYPE, degen_csv)
vsp.ComputeDegenGeom(vsp.SET_ALL, vsp.DEGEN_GEOM_CSV_TYPE)
```

The Analysis Manager alternatives `DegenGeom` and `VSPAERODegenGeom` may be preferable in release-specific workflows.

### CAD And Mesh Export

```python
vsp.ExportFile("A-geo/openvsp/exports/aircraft.step",
               vsp.SET_ALL, vsp.EXPORT_STEP)
vsp.ExportFile("A-geo/openvsp/exports/aircraft.stl",
               vsp.SET_ALL, vsp.EXPORT_STL)
```

OpenVSP also supports formats such as IGES, Gmsh, Cart3D, VSPGeom, X3D, and airfoil files. Select the format from the receiving solver's needs.

Validate exported geometry independently:

- Units and scale.
- Component and surface names.
- Watertightness and non-manifold edges.
- Surface normals and duplicated symmetry surfaces.
- Thin trailing edges and small gaps.
- Control-surface and propulsion boundaries.
- Far-field/domain construction outside OpenVSP when required.

Do not treat an OpenVSP surface export as a solver-ready volume mesh.

## 8. VSPAERO Setup And Execution

VSPAERO is a potential-flow tool. Define the analysis contract before execution:

- VLM, panel, or hybrid method.
- Geometry Set/Mode.
- Reference area, span, chord, and moment center.
- Mach, Reynolds reference, alpha, beta, and number of points.
- Wake iterations, wake shape, symmetry, and ground effect.
- Steady, stability, control, propeller/rotor, or unsteady mode.
- Tessellation and convergence settings.

Use the installed analysis schema:

```python
def set_double_if_present(analysis, key, values):
    names = set(vsp.GetAnalysisInputNames(analysis))
    if key in names:
        vsp.SetDoubleAnalysisInput(analysis, key, list(values))

def set_int_if_present(analysis, key, values):
    names = set(vsp.GetAnalysisInputNames(analysis))
    if key in names:
        vsp.SetIntAnalysisInput(analysis, key, list(values))

geometry_analysis = "VSPAEROComputeGeometry"
vsp.SetAnalysisInputDefaults(geometry_analysis)
vsp.PrintAnalysisInputs(geometry_analysis)
geometry_result = vsp.ExecAnalysis(geometry_analysis)
if not geometry_result:
    raise RuntimeError("VSPAERO geometry preparation failed")

sweep_analysis = "VSPAEROSweep"
vsp.SetAnalysisInputDefaults(sweep_analysis)
vsp.PrintAnalysisInputs(sweep_analysis)

# Confirm these names against PrintAnalysisInputs for the installed release.
set_double_if_present(sweep_analysis, "MachStart", [0.20])
set_double_if_present(sweep_analysis, "MachEnd", [0.20])
set_int_if_present(sweep_analysis, "MachNpts", [1])
set_double_if_present(sweep_analysis, "AlphaStart", [-4.0])
set_double_if_present(sweep_analysis, "AlphaEnd", [12.0])
set_int_if_present(sweep_analysis, "AlphaNpts", [17])

sweep_result = vsp.ExecAnalysis(sweep_analysis)
if not sweep_result:
    raise RuntimeError("VSPAERO sweep failed")
```

Do not silently skip required inputs. The helper above is suitable for cross-release discovery, but production scripts must fail when a required input is unavailable.

### Reference Quantities

Use a named reference wing where appropriate:

```python
vsp.SetVSPAERORefWingID(wing_id)
```

Read back reference values. Coefficients from different area/span/chord references are not directly comparable.

### Sensitivity

Run at least:

- Chordwise and spanwise tessellation refinement.
- Wake iteration and wake-length/refinement checks.
- VLM versus panel/hybrid comparison when both are meaningful.
- Symmetry versus full-model checks for asymmetric/control cases.
- Small perturbation checks for stability derivatives.

## 9. Results And Post-Processing

Discover results instead of hard-coding one file:

```python
def result_inventory(result_id):
    inventory = {}
    for name in vsp.GetAllDataNames(result_id):
        inventory[name] = vsp.GetResultsType(result_id, name)
    return inventory

print(result_inventory(sweep_result))
```

Use typed accessors such as `GetDoubleResults`, `GetIntResults`, `GetStringResults`, and matrix/vector accessors according to the reported type.

Extract and plot:

- `C_L-alpha` and lift-curve slope.
- `C_D-C_L` polar and `L/D`.
- `C_M-alpha`, trim points, and moment reference.
- Lateral/directional forces and moments versus beta.
- Spanwise circulation/load and sectional coefficients.
- Stability/control derivatives with sign convention.
- Pressure or delta-pressure slices where available.
- Convergence and unsteady histories.

Write tidy CSV/JSON tables with units, model hash, operating point, method, references, and version. Keep raw VSPAERO files unchanged.

## 10. Parameter Studies And Optimization

Use one deterministic model builder:

1. Load design variables from JSON.
2. Clear/load a known baseline.
3. Apply every controlled parameter.
4. Update and validate geometry.
5. Save a uniquely named `.vsp3`.
6. Run geometry and aerodynamic analyses.
7. Extract a machine-readable result.
8. Return explicit constraints and failure category.

Cache by the hash of:

- OpenVSP/VSPAERO version.
- Builder script.
- Baseline model.
- Design vector.
- Analysis configuration.
- Reference quantities.

For parallel studies, use separate processes and directories. The OpenVSP MultiFacade API can manage multiple independent instances, but isolate output names and validate process cleanup.

## 11. High-Fidelity Handoff

Use OpenVSP/VSPAERO to screen and initialize, then hand off selected candidates:

- SU2 or OpenFOAM for open-source viscous/compressible CFD.
- Fluent or STAR-CCM+ for commercial CFD and complex workflows.
- CalculiX or Abaqus for structural loads and deformation.
- Coupled workflows when deformation, propulsion, or controls materially change aerodynamics.

Create a handoff manifest containing:

- Geometry/export file and hash.
- Units, axes, origin, and reference quantities.
- Component-to-boundary mapping.
- Flight condition and mass state.
- Control/propulsion configuration.
- VSPAERO result used for comparison.
- Known geometry repairs or simplifications.

## 12. Failure Diagnosis

| Symptom | Likely category | First action |
| --- | --- | --- |
| `import openvsp` fails | Python ABI/path | Use Setup-matched Python or `vspscript` |
| VSPAERO not found from Python | Tool path | Call `SetVSPAEROPath` with the executable directory |
| Empty result ID | API/analysis setup | Drain errors and print installed analysis inputs |
| Implausible coefficients | References/geometry/condition | Check units, Sref/bref/cref, axes, alpha/beta, and component sets |
| VSPAERO divergence | Geometry/wake/discretization | Inspect trailing edges, intersections, tessellation, wake, and method |
| Oscillatory span load | Tessellation/geometry | Refine and inspect section transitions and control-surface edges |
| Drag disagreement | Model scope | Separate induced, parasite, trim, wave, installation, and cooling drag |
| Export not watertight | Geometry/export | Inspect caps, intersections, symmetry, thin edges, and export settings |
| Rerun erased results | Output collision | Use unique basenames and preserve raw files before execution |

Do not alter requirements or physical conditions to hide a toolchain or geometry failure.

## 13. Completion Checklist

- Headless rebuild succeeds from a clean process.
- `.vsp3`, manifest, and preview exports exist and reopen.
- API error stack is empty.
- Component names, Sets, Modes, and control groups match the design contract.
- Geometry, mass-property, and clearance checks are recorded.
- VSPAERO references, method, wake, tessellation, and operating points are explicit.
- Sensitivity studies support the selected numerical settings.
- Results are exported to machine-readable tables and publication-quality figures.
- Limitations and high-fidelity validation needs are recorded.
