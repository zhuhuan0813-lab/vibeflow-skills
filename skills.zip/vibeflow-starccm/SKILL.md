---
name: vibeflow-starccm
description: Use when preparing, parameterizing, running headlessly, debugging, or post-processing Simcenter STAR-CCM+ commercial CFD and multiphysics workflows in VibeFlow/VibeCAE, including .sim/.simt templates, Java macros, Simulation Operations, batch execution, CPU/GPU parallelism, reports, scene export, licensing, and version compatibility.
---

# VibeFlow STAR-CCM+

This skill maps the physical intent in `0-caseDict/caseDict` to traceable STAR-CCM+ templates, macros, batch commands, and result evidence. Use headless batch execution by default; do not depend on manual GUI interaction.

## 使用边界

只执行用户请求范围内的工作。下文流程、产物和验证按当前模式及实际依赖选用，参考资料按需读取；转交其他 Skill 表示继续处理依赖，不表示停止。阶段验收不新增审批；已有授权持续有效。纯诊断和局部修改不要求完成整套建模、求解、报告或重建目录。

## When To Use

- The user explicitly selects STAR-CCM+ or provides a `.sim`, `.simt`, or Java macro.
- The task must automate CAD/mesh import, continua and boundary setup, volume meshing, steady/transient solution, or result export.
- An enterprise template, Simulation Operations workflow, or Design Manager parameter set must be integrated into VibeFlow.
- Batch execution, licensing, CPU/GPU parallelism, macro API, or release-upgrade failures need diagnosis.

## Choose The Working Mode First

- Current-case setup, execution, and post-processing: use usage mode.
- Reusable Java macros, template generators, adapters, or log parsers: use development mode and document design and validation in `UDF/README.md`.
- Missing command, version, or license environment: switch to `vibeflow-toolchain` first.
- Incomplete geometry or mesh facts: return to `vibeflow-case-dict`, `vibeflow-geometry`, or `vibeflow-mesh`.

## Read First

- `0-caseDict/caseDict`: physics, materials, regions, boundaries, mesh, numerical method, execution, and post-processing targets.
- `references/starccm-playbook.md`: commands, templates, macros, batch execution, and artifact layout.
- `references/starccm-practical-tips.md`: licensing, releases, stability, recovery, and troubleshooting.
- Enterprise templates, baseline `.sim/.simt` files, recorded macros, and user manuals under `Ref/`.
- `cae.starccm` and `cae.starccmVersion` from the Setup context; revalidate them before use.

## Inputs And Outputs

Inputs include `caseDict`, CAD/mesh assets, a baseline `.sim/.simt`, macros, and required material data. Recommended output layout:

```text
C-run/starccm/case-1/
├── input/
├── template/
├── macros/
├── run/
├── logs/
├── exports/
├── case-manifest.md
└── run-starccm.ps1
```

- Keep a read-only baseline copy under `template/`; write production models under `run/` and never overwrite the template.
- Keep release-matched Java source and parameter contracts under `macros/`.
- Store CSV, images, animations, or exchange files under `exports/`, and console output under `logs/`.

## Usage-Mode Workflow

1. Read `caseDict` and confirm solver type, dimensionality, materials, reference values, boundaries, meshing strategy, stopping criteria, output cadence, and hardware resources.
2. Choose the automation layer: prefer `.simt/.sim` templates and Simulation Operations; put only behavior that templates cannot express into Java macros.
3. Copy the template into the current case and record template version, STAR-CCM+ release, macro version, and input hashes.
4. Run a setup-only or mesh-only smoke stage and verify parts, regions, interfaces, boundaries, and mesh statistics.
5. Run a short solution stage and verify physics continua, initial conditions, monitors, residuals, conservation, and stopping criteria.
6. Execute the full workflow with `starccm+ -batch ...`; launch Windows commercial software from a Windows terminal.
7. Make macros or Simulation Operations explicitly save the result `.sim`, tables, scenes, and reports; do not rely on in-memory state.
8. Check process exit code, severe log errors, final iteration/physical time, convergence indicators, and exports.
9. Write release, command, resources, license mode, inputs, outputs, and failures back to `caseDict` and the case manifest.

## Development-Mode Workflow

1. Define the development target: Java macro, template, Simulation Operations sequence, parameter driver, export adapter, or log parser.
2. Read the target release's local Programming Guide/API and a macro recorded with that release; never construct APIs from memory of another release.
3. Record object-tree assumptions, inputs, outputs, idempotency strategy, output contract, supported releases, and minimal validation model in `UDF/README.md`.
4. Resolve objects by stable names or tags and check existence before creating them, avoiding duplicate regions, reports, and scenes.
5. Validate setup, save, reopen, batch execution, and export on a small `.sim` before integration with a production case.

## Core Rules

- `caseDict` is the physical/numerical source of truth; `.sim/.simt` files are backend execution artifacts. Keep their mapping traceable.
- Never overwrite a user-supplied `.sim/.simt`; run copied working files.
- The Java API is release-sensitive. Record the macro's development release and calibrate against local documentation and recorded macros.
- Never store license servers, keys, tokens, or credentials in `caseDict`, skills, scripts, or shared logs.
- A successful Setup `-version` probe does not prove model-feature or license availability; run a small model before production.
- Record process count, GPU selection, and license mode explicitly; do not infer them blindly from workstation core count.
- Every batch run needs a timeout policy, logs, explicit output paths, and a repeatable cleanup/recovery strategy.

## Acceptance

- `starccm+ -version` succeeds and the release is compatible with the template and macros.
- A short batch run loads a copied model, executes the intended stage, saves a new `.sim`, and exits normally.
- Mesh, boundaries, continua, stopping criteria, and key reports match `caseDict`.
- The production run produces parseable logs, convergence evidence, and at least one independent result export.
- Failures can be classified as licensing, release/API, geometry/mesh, physics setup, numerical divergence, or export failures.

## Fallbacks

- Template/macro incompatibility: resave the template with the target release or update the macro from local API documentation.
- Missing command or license: return to `vibeflow-toolchain`; do not modify physics to hide an environment failure.
- Geometry or mesh failure: return to geometry/mesh and preserve boundary semantics.
- Insufficient results: add monitors, reports, and exports, then rerun the relevant stage rather than forcing report generation.
