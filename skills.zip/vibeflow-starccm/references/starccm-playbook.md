# STAR-CCM+ Automation Playbook

## Official References

- Siemens STAR-CCM+ product page: https://plm.sw.siemens.com/en-US/simcenter/fluids-thermal-simulation/star-ccm/
- Simulation Templates: https://blogs.sw.siemens.com/simcenter/simulation-templates-your-magic-typewriter-for-cfd-automation/
- STAR-CCM+ 2406 automation capabilities: https://blogs.sw.siemens.com/simcenter/simcenter-star-ccm-2406-released/
- Simulation Operations: https://blogs.sw.siemens.com/simcenter/Simcenter-STAR-CCM-2019-2-Whats-New/
- Treat the Help and Programming Guide installed with the target release as authoritative for command-line and Java API details.

The STAR-CCM+ Java API and model files change between releases. Online references explain the workflow, but generate production macros only after checking the target installation documentation, existing enterprise macros, or macros recorded with the target release.

## VibeFlow Configuration Keys

| Key | Meaning |
| --- | --- |
| `cae.starccm` | Resolved `starccm+` or `starccm+.bat` entry |
| `cae.starccmVersion` | Version summary recorded by the Setup `-version` probe |
| `VIBEFLOW_STARCCM` | Recommended command environment variable |

The Setup probe does not load a `.sim`, so it does not prove availability of licenses, physics modules, parallel features, or GPU features.

## Choose The Automation Layer

| Scenario | Preferred Approach | Rationale |
| --- | --- | --- |
| Enterprise standard shared by many users | `.simt` template plus Simulation Operations | Encodes best practices and minimizes API maintenance |
| Existing `.sim` with parameter-only changes | Global parameters plus Batch | Small change surface and lower release risk |
| Dynamic object-tree creation or queries | Java macro | Supports conditional and complex operations |
| Mesh-only or solve-only stage | Batch action or staged template operation | Enables smoke tests and failure isolation |
| Persistent service or interactive control | Server/client or enterprise scheduler integration | Requires additional security, port, and license design |

Keep stable and reviewable logic in templates and Simulation Operations. Use short Java macros only for behavior those layers cannot express. Do not reimplement the entire GUI workflow in one large macro.

## Recommended Layout And Manifest

```text
C-run/starccm/case-1/
+-- input/geometry-or-mesh/
+-- template/baseline.simt
+-- macros/VibeFlowConfigure.java
+-- macros/VibeFlowExport.java
+-- run/case-working.sim
+-- run/case-result.sim
+-- logs/starccm-console.log
+-- exports/reports.csv
+-- exports/scenes/
`-- case-manifest.md
```

At minimum, `case-manifest.md` records:

- Full STAR-CCM+ release and platform.
- Template path, source, and hash.
- Macro files, development release, and parameters.
- Mapping from `caseDict` regions/boundaries to STAR-CCM+ names.
- License mode, process count, GPU selection, and host list.
- Command, start/end time, exit code, and output files.

## Lightweight Checks

PowerShell:

```powershell
$star = $env:VIBEFLOW_STARCCM
& $star -version
& $star -help
```

Do not load a `.sim` when only installation and version need validation. The target release may provide `-info` for simulation metadata; run it only on a case working copy.

## Common Batch Patterns

These commands are workflow skeletons. Confirm the exact options with the target installation's `starccm+ -help` and Command-Line Reference:

```powershell
# Run the solution workflow already configured in the model.
& $star -batch run 'run/case-working.sim' *> 'logs/starccm-console.log'

# Execute a Java macro.
& $star -batch 'macros/VibeFlowConfigure.java' 'run/case-working.sim' *> 'logs/configure.log'

# Run in parallel.
& $star -np 8 -batch run 'run/case-working.sim' *> 'logs/run.log'
```

Important details:

- Omitting `-batch` may start the GUI.
- Check `$LASTEXITCODE` in the outer PowerShell process; file existence alone is not success.
- Select process count, `-machinefile`, GPU, and license options from local help and organization policy.
- Parameter injection syntax depends on release and object type. Check target-release help before using `-param`.

## Java Macro Contract

A minimal macro normally extends `StarMacro` and starts from the active simulation:

```java
import star.common.*;

public class VibeFlowRun extends StarMacro {
    @Override
    public void execute() {
        Simulation sim = getActiveSimulation();
        sim.println("VIBEFLOW_STAGE=begin");
        // Resolve existing objects by stable names/tags, validate, then modify.
        sim.println("VIBEFLOW_STAGE=end");
    }
}
```

Macro rules:

1. Validate input files, object names, and parameters up front; throw contextual exceptions on missing inputs.
2. Resolve objects through stable names or tags and check for existing objects before creating them.
3. Emit machine-readable markers such as `VIBEFLOW_STAGE=mesh` at major stages.
4. Use case-relative paths or command parameters for exports; never hard-code user directories.
5. Save a new `.sim`; overwrite a working copy only when explicitly authorized.
6. Note the API provenance near release-sensitive calls, for example `recorded with 20.06`.

## Mapping From caseDict

| caseDict Concept | STAR-CCM+ Object | Validation |
| --- | --- | --- |
| `geometry.entities` | Parts and Part Surfaces | Names, units, watertightness |
| `regions` | Regions | Expected fluid/solid domain count |
| `interfaces` | Interfaces and Contacts | Both sides and coupling model |
| `materials` | Continua and Material Properties | Units, temperature dependence, composition |
| `boundarySets` | Boundaries | Type and profile consistency |
| `mesh` | Mesh Continua and Operations | Base size, layers, quality |
| `numericalMethod` | Solvers and Stopping Criteria | Steady/transient, time step, schemes |
| `postProcessing` | Reports, Monitors, Plots, Scenes | Exportability, comparability, stable names |

Write this mapping into the case manifest. When template names differ from `caseDict`, record an explicit mapping instead of silently renaming source-of-truth concepts.

## Stage Validation

### Setup

- Every CAD/mesh input is accessible and uses the expected units.
- Counts of Parts, Regions, Boundaries, and Interfaces match expectations.
- Physics combinations are internally consistent, including density, energy, turbulence, and wall treatment.

### Mesh

- Record total cells, element types, minimum volume, and quality indicators in logs or CSV.
- Inspect thin layers, narrow gaps, prism layers, and interface regions explicitly.
- Repeated mesh execution must not accumulate duplicate controls.

### Solution

- A short run produces residuals and engineering monitors.
- Mass/energy balance, force, pressure drop, or other targets are physically plausible.
- Stopping criteria include both a hard maximum and physical convergence criteria.

### Results

- The `.sim` saves successfully and reopens.
- Report CSV files include headers, units, and operating-point identity.
- Scene exports use fixed camera, resolution, color range, and naming.
- Cross-tool exports record format and release information.

## Failure Classification

| Symptom | Category | First Action |
| --- | --- | --- |
| Launcher not found | Toolchain | Check Setup path and `VIBEFLOW_STARCCM` |
| No available license | License | Check license service and product feature; do not edit the case |
| Macro class/method missing | Release/API | Use the target Programming Guide and a recorded macro |
| `.sim` requires a newer release | Release | Use a compatible release and preserve the original file |
| Meshing failure | Geometry/mesh | Inspect surfaces, leaks, scale, and local controls |
| Exploding residuals | Numerical/physics | Inspect initialization, boundaries, time step, mesh, and models |
| Batch exits without exports | Workflow | Inspect macro exceptions, save/export paths, and exit code |

## Completion Criteria

- A copied working model completes headless batch execution and exits normally.
- Key objects, mesh, physics, and stopping criteria align with `caseDict`.
- `.sim`, logs, CSV/images, and other evidence are complete.
- Command, release, resources, license mode, and failures remain traceable.
