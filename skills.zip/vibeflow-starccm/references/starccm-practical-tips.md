# STAR-CCM+ Practical Tips

## Prefer Templates; Use Macros For Deltas

- Use `.simt` to encode physics, mesh, reports, and Simulation Operations.
- Use Java macros for external parameters, conditional creation, and batch export.
- One macro per clear stage is easier to upgrade than a monolithic import-to-report macro.
- Keep reviewable enterprise standards in templates so experts can inspect them in the GUI.

## Release Compatibility

- Upgrading `.sim/.simt` files is usually not reversible; copy them first.
- Record the target release in macro source and use the local Programming Guide for compilation errors.
- Recorded macros reveal real classes and call patterns for a release, but remove selection state, hard-coded IDs, and redundant UI actions.
- Never move a web example from another major release directly into production.

## Idempotency

- Resolve reports, monitors, scenes, and mesh controls by name before creation.
- When rebuilding, delete only macro-owned objects with an explicit `VF_` prefix.
- Repeated parameterized execution must preserve object counts and names.
- Emit stage markers and save checkpoints to support recovery from setup, mesh, or solution stages.

## Windows Paths

- Launch Windows STAR-CCM+ from Windows PowerShell rather than through a WSL-translated launcher.
- Use PowerShell's call operator `&` for paths containing spaces.
- Pass paths into Java through arguments/environment and combine them with Java `Path`/`File` APIs.
- Create output directories before launch; never default to the install directory or an ambiguous working directory.

## Licensing

- `-version` checks installation; loading a model or starting a server may request a license.
- Organization policy determines license mode and parallel capacity; the skill does not choose Power Session or token policy for the user.
- Preserve license errors for diagnosis, but redact server details before sharing logs.
- Limit batch concurrency to avoid exhausting shared licenses.

## Parallelism And GPU

- Choose CPU process count from mesh scale, memory bandwidth, and licensing, not logical core count alone.
- Benchmark two or three representative process counts before production.
- GPU options support only certain model combinations; confirm from logs that execution did not silently fall back to CPU.
- Multi-host runs require explicit machine files, shared paths, MPI compatibility, and firewall readiness.

## Convergence Is More Than Residuals

- Monitor mass/energy imbalance and engineering targets such as force, pressure drop, temperature, and flow rate.
- Falling residuals with drifting target quantities is not convergence.
- For transient cases, inspect sampling windows, output cadence, and periodicity rather than only the last step.
- Keep mesh/model/time-step variants as separate operating points rather than overwriting a baseline.

## Logs And Progress

- Redirect console output to a dedicated log and record the exit code.
- Emit short machine markers; external tools should parse stable markers, not complete UI messages.
- Read long logs incrementally instead of rescanning the whole file.
- On interruption, confirm whether STAR-CCM+ is still saving before restarting.

## Data And Post-Processing

- A `.sim` supports continuation but is not sufficient as the only deliverable.
- CSV exports include units, reference values, operating point, and statistical window.
- Keep camera, color map, limits, and visible objects fixed for cross-case scene comparisons.
- Export only fields and regions needed to answer the question for large transient datasets.

## Most Common Failure Order

1. Missing path or license.
2. Incompatible template and runtime release.
3. Macro API mismatch.
4. Incorrect surfaces, regions, or interface names.
5. Mesh scale or prism-layer failure.
6. Divergence from initialization, boundaries, time step, or physics.
7. Successful solve followed by export path/object-name failure.

Investigating in this order prevents environment failures from being misclassified as physics failures.
